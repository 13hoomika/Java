class DFantasy{
	static String ingredientType = "Vegetarian";
	static String brand = "Sunfeast Dark Fantasy";
	static String packageInformation = "Box";
	static int itemModelNo = 89017;
	static double netQuantityInGms = 242.0;
	
	public static void main(String choco[]){
		// String ingredientType = "Vegetarian";
		// String brand = "Sunfeast Dark Fantasy";
		// String packageInformation = "Box";
		// int itemModelNo = 89017;
		// double netQuantityInGms = 242.0;
		
		System.out.println("Ingredient Type:" + ingredientType);
		System.out.println("Brand:" + brand);
		System.out.println("Package Information:" + packageInformation);
		System.out.println("Item Model Number:" + itemModelNo);
		System.out.println("Net Quantity in Gms:" + netQuantityInGms);
	}
}