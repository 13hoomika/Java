class MuesliDal{
	static String brand = "Bharath Dal";
	static String dietType = "Vegetarian";
	static String flavour = "Fruit & Nut";
	static String itemForm = "flaked";
	static double price = 350.0;
	
	public static void main(String oats[]){
	// String brand = "Kellogg's";
	// String dietType = "Vegetarian";
	// String flavour = "Fruit & Nut";
	// String itemForm = "flaked";
	// double price = 350.0;
	
	System.out.println("Brand:" + brand);
	System.out.println("Diet Type:" + dietType);
	System.out.println("Flavour:" + flavour);
	System.out.println("Item Form:" + itemForm);
	System.out.println("Price:" + price);

	}
}
