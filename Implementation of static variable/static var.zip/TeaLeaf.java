class TeaLeaf{
	static String brand = "Taaja";
	static String itemForm = "Loose Leaves";
	static String flavour = "Black Tea";
	static String teaVariety = "Chai";
	static double netQuantity = 1.00;
	
	public static void main(String tea[]){
		// String brand = "Taaja";
		// String itemForm = "Loose Leaves";
		// String flavour = "Black Tea";
		// String teaVariety = "Chai";
		// double netQuantity = 1.00;
		
		System.out.println("Brand:" + brand);
		System.out.println("Item Form:" + itemForm);
		System.out.println("Flavour:" + flavour);
		System.out.println("Tea Variety:" + teaVariety);
		System.out.println("Net Quantity:" + netQuantity);

	}
}