class WashingPowder{
	static String brand = "Surf excel";
	static String itemForm = "Powder";
	static String scent = "Floral";
	static double netQuantityInGms = 5000.0;
	static String materialTypeFree = "Chemical Free";
	static String formulationType = "Cold Water";
		
		public static void main(String pow[]){
		// String brand = "Surf excel";
		// String itemForm = "Powder";
		// String scent = "Floral";
		// double netQuantityInGms = 5000.0;
		// String materialTypeFree = "Chemical Free";
		// String formulationType = "Cold Water";
		
		System.out.println("Brand:" + brand);
		System.out.println("Item Form:" + itemForm);
		System.out.println("Scent:" + scent);
		System.out.println("Net Quantity in Gms:" + netQuantityInGms);
		System.out.println("Material Type Free:" + materialTypeFree);
		System.out.println("Formulation:" + formulationType);
	}
}