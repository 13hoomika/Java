class Iqoo{
	static String brand = "iQOO";
	static String os = "Funtouch OS 14 based on Android 14";
	static int ramInGb = 6;
	static String cpu = "snapdragon";
	static int memoryInGb = 128;
	
	public static void main(String mobile[]){
		// String brand = "iQOO";
		// String os = "Funtouch OS 14 based on Android 14";
		// int ramInGb = 6;
		// String cpu = "snapdragon";
		// int memoryInGb = 128;
		
		System.out.println("Mobile brand name "+brand);
		System.out.println("iQOO's Operating System "+os);
		System.out.println("iQOO's RAM Memory Installed Size in GB "+ramInGb);
		System.out.println("iQOO's CPU Model is "+cpu);
		System.out.println("iQOO's Memory Storage Capacity "+ memoryInGb);
	}
}