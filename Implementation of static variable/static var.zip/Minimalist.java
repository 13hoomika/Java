class Minimalist{
	static String  scent = "Unscented";
	static String brand = "Minimalist";
	static String skinType = "All";
	static String useFor = "face";
	
	public static void main(String skincare[]){
		// String  scent = "Unscented";
		// String brand = "Minimalist";
		// String skinType = "All";
		// String useFor = "face";
		
		System.out.println("Scent is" + scent);
		System.out.println("Brand Name is " + brand);
		System.out.println("Skin Type is " + skinType);
		System.out.println("Use For is " + useFor);
		
	}
}