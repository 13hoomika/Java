class Anc{
	static String brand = "Noise";
	static String color = "Chrome Black";
	static String earPlacement = "In Ear";
	static String fromFactor = "true Wireless";
	static String noiseControl = "Active Noise Canclellation";
	public static void main(String earbuds[]){
		// String brand = "Noise";
		// String color = "Chrome Black";
		// String earPlacement = "In Ear";
		// String fromFactor = "true Wireless";
		// String noiseControl = "Active Noise Canclellation";
		
		System.out.println("ANS's Brand Name is " +brand);
		System.out.println("ANS's Color is "+ color);
		System.out.println("ANS's Ear Placement"+ earPlacement);
		System.out.println("ANS's Form Factor"+ fromFactor );
		System.out.println("ANS's Noise control"+ noiseControl);
	}
}