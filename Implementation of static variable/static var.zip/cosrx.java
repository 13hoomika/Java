class cosrx{
	static String skinType = "Oily, Combination";
	static String productBenefits = "Soothing, Dark Spots, Improves Skin Vitality, Repairs, Moisturising, Nourishes, Plumps";
	static String scent = "uncented";
	static String brand= "COSRX";
	static String itemForm = "cream";
	static String meterialfeature = "Natural";
	static int itemweightInGms = 13;
	static String meterialType = "alchohol Free";
	static String skinTone= "All";
	static int itemVolumeInMl= 100;
	
	public static void main(String serum[]){
		//String skinType = "Oily, Combination";
		//String productBenefits = "Soothing, Dark Spots, Improves Skin Vitality, Repairs, Moisturising, Nourishes, Plumps";
		//String scent = "uncented";
		//String brand= "COSRX";
		//String itemForm = "cream";
		//String meterialfeature = "Natural";
		//int itemweightInGms = 13;
		//String meterialType = "alchohol Free";
		//String skinTone= "All";
		//int itemVolumeInMl= 100;
		
		System.out.println("COSRX skin type is " +skinType);
		System.out.println("COSRX productBenefits is " +productBenefits);
		System.out.println("COSRX scent is " +scent);
		System.out.println("COSRX brand is " +brand);
		System.out.println("COSRX Item Form is " + itemForm);
		System.out.println("COSRX meterialfeature is " + meterialfeature);
		System.out.println("COSRX  itemweightInGms is " +itemweightInGms);
		System.out.println("COSRX Skin Tone is " +skinTone);
		System.out.println("COSRX Meterial Type is " + meterialfeature);
		System.out.println("COSRX Item Volume In Ml is " +itemVolumeInMl);

	}
}