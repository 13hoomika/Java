class MysSoap{
	static String brand = "Mysore Sandal";
	static String ageRange = "Adult";
	static String skinType = "Normal";
	static String productBenefits = "Moisturizer,Nourishing";
	static int noOfPieces = 1;
	
	public static void main(String soap[]){
	// String brand = "Mysore Sandal";
	// String ageRange = "Adult";
	// String skinType = "Normal";
	// String productBenefits = "Moisturizer,Nourishing";
	// int noOfPieces = 1;
	
	System.out.println("Brand:" + brand);
	System.out.println("Age Range:" + ageRange);
	System.out.println("Skin Type:" + skinType);
	System.out.println("Product Benefits:" + productBenefits);
	System.out.println("Number Of Pieces:" + noOfPieces);
	}
}