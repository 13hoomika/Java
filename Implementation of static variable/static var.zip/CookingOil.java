class CookingOil{
	
	static String flavour = "Mustard";
	static String brand = "Fortune";
	static String netContent = "1 Litres";
	static String specialFeature = "Cold Pressed";
	static String itemForm = "Liquid";
	static String recommendedUses = "Cooking";
	
	public static void main(String oil[]){
	
	System.out.println("Flavour: " + flavour);
	System.out.println("Brand: " + brand);
	System.out.println("Net Content Volume: " + netContent);
	System.out.println("Special Feature: " + specialFeature);
	System.out.println("Item Form: " + itemForm);
	System.out.println("Recommended Uses: " + recommendedUses);
	}
}