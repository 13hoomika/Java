class Disinfectant{
	static String countryOrigin = "India";
	static int itemModelNo = 82589;
	static int weightInKg = 5;
	static String asin = "DI55893";
		
	public static void main(String sanitizer[]){
		// String countryOrigin = "India";
		// int itemModelNo = 82589;
		// int weightInKg = 5;
		// String asin = "DI55893";
		
		System.out.println("Country Of Origin:" + countryOrigin);
		System.out.println("Item Model Number:" + itemModelNo);
		System.out.println("Weight in KG:" + weightInKg);
		System.out.println("ASIN:" + asin);

	}
}