class Bed{
	static String color= "Antique White";
	static String brand= "Wooden Twist";
	static String sizeInCm = "215*205*131" ;
	static String shape="Round" ;
	static String iteDimention= "2.15*2.05*1.31" ;
	
	public static void main(String bed[]){
		// String color= "Antique White";
		// String brand= "Wooden Twist";
		// String sizeInCm = "215*205*131" ;
		// String shape="Round" ;
		// String iteDimention= "2.15*2.05*1.31" ;
		
		System.out.println("Bed Color"+color);
		System.out.println("Bed Brand "+brand);
		System.out.println("Bed Size in Centimeter "+ sizeInCm);
		System.out.println("Bed Shape "+ shape);
		System.out.println("Bed Dimention "+ iteDimention);
	}
}