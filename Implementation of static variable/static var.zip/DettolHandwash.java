class DettolHandwash{
	static String brand = "Dettol";
	static String itemWeight = "500 Gms";
	static String scent = "Rose";
	static String skinType = "All";
	static String activeIngridents = "HandWash";
	
	public static void main(String handwash[]){
		// String brand = "Dettol";
		// String itemWeight = "500 Gms";
		// String scent = "Rose";
		// String skinType = "All";
		// String activeIngridents = "HandWash";
		
		System.out.println("Brand:" + brand);
		System.out.println("Item Weight:" + itemWeight);
		System.out.println("Scent:" + scent);
		System.out.println("Skin Type:" + skinType);
		System.out.println("Active Ingridents:" + activeIngridents);
	}
}