class Dal{
	static String brand = "Bharath Dal";
	static String itemWeight = "1 KG";
	static String speciality = "Vegetarian";
	static String itemForm = "Whole";
	
	public static void main(String jam[]){
		// String brand = "Bharath Dal";
		// String itemWeight = "1 KG";
		// String speciality = "Vegetarian";
		// String itemForm = "Whole";
		
		System.out.println("Brand:" + brand);
		System.out.println("Item Weight:" + itemWeight);
		System.out.println("Speciality:" + speciality);
		System.out.println("Item Form: " + itemForm);
	}
}