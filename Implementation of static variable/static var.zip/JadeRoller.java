class JadeRoller{
	static String useFor = "Face";
	static String powerSource = "Manual";
	static String material = "Brass Metal";
	static int iteamWeightInGms = 80;
	static String massagerForm = "Massage Roller";
	static String productBenefits = "Firming";
	static boolean isItCordless = false;
	static String productDimention = "10L * 8W * 5H Centimeters";
	
	public static void main(String roller[]){
		// String useFor = "Face";
		// String powerSource = "Manual";
		// String material = "Brass Metal";
		// int iteamWeightInGms = 80;
		// String massagerForm = "Massage Roller";
		// String productBenefits = "Firming";
		// boolean isItCordless = false;
		// String productDimention = "10L * 8W * 5H Centimeters";
		
		System.out.println("Jade Roller's used for" + useFor);
		System.out.println("Jade Roller's [power Source" + powerSource);
		System.out.println("Jade Roller's material is" + material);
		System.out.println("Jade Roller's Item weight in grams is" + iteamWeightInGms);
		System.out.println("Jade Roller's massage form is " + massagerForm);
		System.out.println("Jade Roller's product benefits is for " + productBenefits);
		System.out.println("Jade Roller's doesn not have " + isItCordless);
		System.out.println("Jade Roller's dimentions are " + productDimention);
		
	}
}