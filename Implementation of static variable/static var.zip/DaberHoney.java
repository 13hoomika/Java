class DaberHoney{
	static String flavour = "Pure Honeynatural & Raw";
	static String brand = "Disano";
	static String itemWeight = "500 Gms";
	static String packageInfo = "Bottle";
	static String packageWeight = "0.56 kg";
	static String productUses = "Provides Mineral,Antioxidants";
	
	public static void main(String honey[]){
		//String flavour = "Pure Honeynatural & Raw";
		//String brand = "Disano";
		// String itemWeight = "500 Gms";
		// String packageInfo = "Bottle";
		// String packageWeight = "0.56 kg";
		// String productUses = "Provides Mineral,Antioxidants";
		
		System.out.println("Flavour: " + flavour);
		System.out.println("Brand: " + brand);
		System.out.println("Item Weight: " + itemWeight);
		System.out.println("Package Information: " + packageInfo);
		System.out.println("Package Weight: " + packageWeight);
		System.out.println("Product Uses: " + productUses);
	}
}