class SkinCleanser{
	public static void main(String clenser[]){
		String brand = "Cetaphil";
		int iteamWeightInGms = 125;
		String Scent = "Unsented";
		String AgeRange = "18 and above";
		String skinType = "Sensitive, Dry , Normal";
		int itemmPackageQuantity = 1;
		String productBenefits = "cleansing";
		String specialFeature = "Won't Clog Pores, Hypoallergenic, Unsented,pH balanced, Dermatologist tested";
		String activeIngredients = "Hydrating Glycerin, Panthenol(Vitamin B5), Niacinamide(Vitamin B3)";
		
	System.out.println("Skin Cleanser's Bran is " + brand);
	System.out.println("Skin Cleanser's weight in grams is " + iteamWeightInGms);
	System.out.println("Skin Cleanser's sent is " + Scent);
	System.out.println("Skin Cleanser'Age Range is "+ AgeRange);
	System.out.println("Skin Cleanser's skin type is "+ skinType);
	System.out.println("Skin Cleanser's package quntyity is " + itemmPackageQuantity );
	System.out.println("Skin Cleanser's product Benefits is "+ productBenefits);
	System.out.println("Skin Cleanser's special Feature is "+ specialFeature);
	System.out.println("Skin Cleanser's active Ingredients is "+ activeIngredients);	
	
	}

}