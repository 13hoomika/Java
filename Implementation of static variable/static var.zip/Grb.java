class Grb{
	static String brand = "Grb";
	static String flavour = "no flaver";
	static String dietType = "Vegen";
	static String biologicalSource = "Cow";		
	static int itemWeightinGms = 750;
	
	public static void main(String gee[]){
		// String brand = "Grb";
		// String flavour = "no flaver";
		// String dietType = "Vegen";
		// String biologicalSource = "Cow";
		// int itemWeightinGms = 750;
		
		System.out.println("Brand:" + brand);
		System.out.println("Flavour:" + flavour);
		System.out.println("Diet Type:" + dietType);
		System.out.println("Biological Source:" + biologicalSource);
		System.out.println("Item Weight:" + itemWeightinGms);
	}
}