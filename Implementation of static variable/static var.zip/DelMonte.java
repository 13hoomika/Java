class DelMonte{
	static String flavour = "Classic Blend";
	static String itemWeight = "900 Gms";
	static String allergenInfo = "Allergen-Free";
	static String itemForm = "Paste";
	static double netQuantity = 500.0;
	
	public static void main(String sauce[]){
		// String flavour = "Classic Blend";
		// String itemWeight = "900 Gms";
		// String allergenInfo = "Allergen-Free";
		// String itemForm = "Paste";
		// double netQuantity = 500.0;
		
		System.out.println("Flavour:" + flavour);
		System.out.println("Item Weight:" + itemWeight);
		System.out.println("Allergen Information:" + allergenInfo);
		System.out.println("Item Form:" + itemForm);
		System.out.println("Net Quantity:" + netQuantity);
	}
}