class DaburHerb{
	static String brand = "DABUR";
	static String flavour = "Clove";
	static String ageRange = "Adult";
	static String itemForm = "Paste";
	static String materiaFeature = "Vegetarian, Natural";
	static int weightInGms = 200;
	static String productBenefits = "Cavity Protection";
	static int itemPackegeQ = 1;
	static String targetAudience = "Unisex Adults";
	
	public static void main(String oats[]){
		
		// String brand = "DABUR";
		// String flavour = "Clove";
		// String ageRange = "Adult";
		// String itemForm = "Paste";
		// String materiaFeature = "Vegetarian, Natural";
		// int weightInGms = 200;
		// String productBenefits = "Cavity Protection";
		// int itemPackegeQ = 1;
		// String targetAudience = "Unisex Adults";
		
		System.out.println("Brand: " + brand);
		System.out.println("Flavour: " + flavour);
		System.out.println("Age Range To Consume: " + ageRange);
		System.out.println("Item From: " + itemForm);
		System.out.println("Materia Feature: " + materiaFeature);
		System.out.println("Weight In Grams:" + weightInGms);
		System.out.println("Product Benefits:" + productBenefits);
		System.out.println("Item Packege Quantity:" + itemPackegeQ);
		System.out.println("Target Audience:" + targetAudience);
	}
}
