class CellPhone{
	static String brandName = "oneplus";
	static double price = 45000.78;
	static String modelId = "OP423";
	static String color = "Black";
	static int storageInGb = 256;
	
	public static void main(String mobile[]){
		//String brandName;
		//double price = 45000.78;
		//String modelId = "OP423";
		//String color = "Black";
		//String storage = "256Gb";		
		
		System.out.println("The Cell Phone Brand Name is " + brandName);
		System.out.println("The Cell phone Price is" + price);
		System.out.println("The Cell phone Model Id is " + modelId);
		System.out.println("The cell phone Color is " + color);
		System.out.println("The Cell phone Storage in GB is " + storageInGb);
		
	}
}