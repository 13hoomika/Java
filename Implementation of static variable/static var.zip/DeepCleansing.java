class DeepCleansing{
	static String brand = "Neutrogena";
	static double iteamWeightInKGMS = 0.23;
	static String Scent = "Grapefruit";
	static String AgeRange = "Adult";
	static String skinType = "Oily";
	static int itemmPackageQuantity = 1;
	static String productBenefits = "Cleansing";
	static String specialFeature = "Natural Ingredients";
	static String activeIngredients = "Salicylic Acid 2%";
	
	public static void main (String cleansing[]){
		// String brand = "Neutrogena";
		// double iteamWeightInKGMS = 0.23;
		// String Scent = "Grapefruit";
		// String AgeRange = "Adult";
		// String skinType = "Oily";
		// int itemmPackageQuantity = 1;
		// String productBenefits = "Cleansing";
		// String specialFeature = "Natural Ingredients";
		// String activeIngredients = "Salicylic Acid 2%";
		
	System.out.println("Skin Cleanser's Bran is " + brand);
	System.out.println("Skin Cleanser's weight in grams is " + iteamWeightInKGMS);
	System.out.println("Skin Cleanser's sent is " + Scent);
	System.out.println("Skin Cleanser'Age Range is "+ AgeRange);
	System.out.println("Skin Cleanser's skin type is "+ skinType);
	System.out.println("Skin Cleanser's package quntyity is " + itemmPackageQuantity );
	System.out.println("Skin Cleanser's product Benefits is "+ productBenefits);
	System.out.println("Skin Cleanser's special Feature is "+ specialFeature);
	System.out.println("Skin Cleanser's active Ingredients is "+ activeIngredients);
	}

}