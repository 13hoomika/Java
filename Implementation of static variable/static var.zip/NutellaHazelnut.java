class NutellaHazelnut{
	static String brand = "Nutella";
	static String flavour = "Hazelnut";
	static String itemForm = "Spread";
	static String allergenType = "Dairy, Milk, Hazelnuts, Wheat Free, Soy";
	static String nutSeedType = "Hazelnut";
	static String packageInfo = "Jar";
		
	public static void main(String haz[]){
		// String brand = "Nutella";
		// String flavour = "Hazelnut";
		// String itemForm = "Spread";
		// String allergenType = "Dairy, Milk, Hazelnuts, Wheat Free, Soy";
		// String nutSeedType = "Hazelnut";
		// String packageInfo = "Jar";
		
		System.out.println("Brand:" + brand);
		System.out.println("Flavour:" + flavour);
		System.out.println("Item Form:" + itemForm);
		System.out.println("Allergen Type:" + allergenType);
		System.out.println("Nut Seed Type:" + nutSeedType);
		System.out.println("Package Information:" + packageInfo);
	}
}