class Ketchap{
	static String flavour = "Fruit";
	static String dietType= "Vegetarian";
	static String brand = "Kissan";
	static String packInfo = "Tub";
	static int noOfItems = 1;
	
	public static void main(String jam[]){
	// String flavour = "Fruit";
	// String dietType= "Vegetarian";
	// String brand = "Kissan";
	// String packInfo = "Tub";
	// int noOfItems = 1;
	
	System.out.println("Flavour:" + flavour);
	System.out.println("Diet Type:" + dietType);
	System.out.println("Brand:" + brand);
	System.out.println("Package Information:" + packInfo);
	System.out.println("Number Of Items:" + noOfItems);
	}
}